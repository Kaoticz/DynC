var searchData=
[
  ['data_145',['Data',['../struct_dynamic_variable.html#a4dc1b546c64c50afeb12ae5f5b67c2ae',1,'DynamicVariable::Data()'],['../struct_____dynlst_elem.html#a77081eeb76422ba4c8bc1a2375fe4b39',1,'__DynlstElem::Data()']]],
  ['datasize_146',['DataSize',['../struct_____dynlst_elem.html#ad63ad4882de2ff7a089a741deb9e7a59',1,'__DynlstElem']]]
];
