var indexSectionsWithContent =
{
  0: "_acdflnpstv",
  1: "_d",
  2: "d",
  3: "dn",
  4: "acdflnpst",
  5: "_dv",
  6: "d",
  7: "dn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros"
};

