var searchData=
[
  ['newdynamicarray_71',['NewDynamicArray',['../dynarr_8h.html#a30ac7921c7dfb185a44b850990d3b6d1',1,'dynarr.c']]],
  ['newdynlist_72',['NewDynlist',['../dynlst_8h.html#a5f7bc485bed0756a07f881853f05563d',1,'dynlst.h']]],
  ['newdynlst_73',['NewDynlst',['../dynlst_8h.html#a50239042389def337fed599fa76ac4d2',1,'dynlst.h']]],
  ['newdynvar_74',['NewDynvar',['../dynvar_8h.html#a358d67ea45b41d4d565e2183079e8118',1,'dynvar.h']]],
  ['next_75',['Next',['../struct_____dynlst_elem.html#a9bb85700adeedf81f4b32786401ea4ba',1,'__DynlstElem']]]
];
