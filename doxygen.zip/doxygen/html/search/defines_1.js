var searchData=
[
  ['newdynlist_164',['NewDynlist',['../dynlst_8h.html#a5f7bc485bed0756a07f881853f05563d',1,'dynlst.h']]],
  ['newdynlst_165',['NewDynlst',['../dynlst_8h.html#a50239042389def337fed599fa76ac4d2',1,'dynlst.h']]],
  ['newdynvar_166',['NewDynvar',['../dynvar_8h.html#a358d67ea45b41d4d565e2183079e8118',1,'dynvar.h']]]
];
