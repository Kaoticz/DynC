var searchData=
[
  ['newdynamicarray_141',['NewDynamicArray',['../dynarr_8h.html#a30ac7921c7dfb185a44b850990d3b6d1',1,'dynarr.c']]]
];
