var struct_dynamic_variable =
[
    [ "Data", "struct_dynamic_variable.html#a4dc1b546c64c50afeb12ae5f5b67c2ae", null ],
    [ "Size", "struct_dynamic_variable.html#a452e88a69cd86aec72ddc176e14c3df4", null ],
    [ "Type", "struct_dynamic_variable.html#abaace22ea07a4ddcc2807f33dd3277d2", null ]
];